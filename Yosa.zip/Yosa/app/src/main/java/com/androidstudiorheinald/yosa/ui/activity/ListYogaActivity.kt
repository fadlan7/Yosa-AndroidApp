package com.androidstudiorheinald.yosa.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.SearchView
import com.androidstudiorheinald.yosa.databinding.ActivityListYogaBinding

class ListYogaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListYogaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListYogaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
/*
        binding.searchYoga.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                val userQuery = query.toString()
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })

 */
        /*
        binding.searchView.apply {
            visibility = View.VISIBLE
            setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String?): Boolean {
                    val userQuery = query.toString()
                    clearFocus()

                    viewModel.userSearch(userQuery).observe(this@MainActivity) {
                        when (it) {
                            is Result.Success -> it.data?.let { data -> onSuccess(data) }
                            is Result.Error -> onFailed(it.error)
                            is Result.Loading -> onLoading()
                        }
                    }
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    return false
                }
            })
        }
        */
    }
}