package com.androidstudiorheinald.yosa.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.androidstudiorheinald.yosa.PreferenceDataStore

class HomeViewModel(private val pref: PreferenceDataStore): ViewModel() {
    fun getOnboard(): LiveData<Boolean> {
        return pref.getOnboard().asLiveData()
    }
}