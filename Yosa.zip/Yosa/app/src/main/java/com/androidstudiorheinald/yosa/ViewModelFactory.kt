package com.androidstudiorheinald.yosa

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.androidstudiorheinald.yosa.ui.viewmodel.HomeViewModel
import com.androidstudiorheinald.yosa.ui.viewmodel.OnboardViewModel

class ViewModelFactory(private val pref: PreferenceDataStore): ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(OnboardViewModel::class.java) -> {
                OnboardViewModel(pref) as T
            }
            modelClass.isAssignableFrom(HomeViewModel::class.java) -> {
                HomeViewModel(pref) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }
}