package com.androidstudiorheinald.yosa

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Level(
    val name: String,
    val photo: Int,
): Parcelable
