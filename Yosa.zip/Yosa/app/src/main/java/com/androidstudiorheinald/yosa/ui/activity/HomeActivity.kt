package com.androidstudiorheinald.yosa.ui.activity

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.androidstudiorheinald.yosa.Level
import com.androidstudiorheinald.yosa.PreferenceDataStore
import com.androidstudiorheinald.yosa.R
import com.androidstudiorheinald.yosa.ViewModelFactory
import com.androidstudiorheinald.yosa.ui.adapter.YogaAdapter
import com.androidstudiorheinald.yosa.databinding.ActivityHomeBinding
import com.androidstudiorheinald.yosa.ui.viewmodel.HomeViewModel

class HomeActivity : AppCompatActivity() {

    private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "after_onboard")
    private lateinit var binding: ActivityHomeBinding
    private lateinit var homeViewModel: HomeViewModel
    private lateinit var yogaAdapter: YogaAdapter
    private val listLevel = ArrayList<Level>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        setupViewModel()
        setupRecyclerView()
        getLevel()
    }

    private fun setupViewModel() {
        val pref = PreferenceDataStore.getInstance(dataStore)
        homeViewModel = ViewModelProvider(this, ViewModelFactory(pref))[HomeViewModel::class.java]

        homeViewModel.getOnboard().observe(this){}
    }

    private fun setupRecyclerView() {
        yogaAdapter = YogaAdapter(listLevel)

        binding.rvLevel.apply {
            adapter = yogaAdapter
            setHasFixedSize(true)
            layoutManager = LinearLayoutManager(this@HomeActivity)
        }
    }

    @SuppressLint("Recycle")
    private fun getLevel() {
        val dataName = resources.getStringArray(R.array.name_level)
        val dataPhoto = resources.obtainTypedArray(R.array.photo_level)
        for(i in dataName.indices) {
            val level = Level(dataName[i], dataPhoto.getResourceId(i, -1))
            this@HomeActivity.listLevel.add(level)
        }
    }
}