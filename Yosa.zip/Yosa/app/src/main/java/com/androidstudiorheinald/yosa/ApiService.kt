package com.androidstudiorheinald.yosa

import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
/*
    @GET("")
    fun getInstruction(

    ): Call<>
 */
}