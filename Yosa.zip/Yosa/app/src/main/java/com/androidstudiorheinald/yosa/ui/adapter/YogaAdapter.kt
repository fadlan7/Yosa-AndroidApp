package com.androidstudiorheinald.yosa.ui.adapter

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.RecyclerView
import com.androidstudiorheinald.yosa.Level
import com.androidstudiorheinald.yosa.R
import com.androidstudiorheinald.yosa.databinding.ItemLevelBinding
import com.androidstudiorheinald.yosa.ui.activity.ListYogaActivity

class YogaAdapter(private val listLevel: ArrayList<Level>): RecyclerView.Adapter<YogaAdapter.ListViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val binding = ItemLevelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        holder.bind(listLevel[position])
    }

    override fun getItemCount(): Int {
        return listLevel.size
    }

    class ListViewHolder(private var binding: ItemLevelBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(level: Level) {
            binding.apply {
                imgLevel.setImageResource(level.photo)
                tvLevel.text = level.name

                itemView.setOnClickListener {
                    Intent(itemView.context, ListYogaActivity::class.java).also {
                        itemView.context.startActivity(it)
                    }
                }
            }
        }
    }
}